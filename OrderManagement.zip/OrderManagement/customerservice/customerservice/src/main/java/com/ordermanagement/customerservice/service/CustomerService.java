package com.ordermanagement.customerservice.service;

import java.util.List;

import com.ordermanagement.customerservice.dto.CustomerDto;
import com.ordermanagement.customerservice.exception.CustomerNotFoundException;
import com.ordermanagement.customerservice.model.Customer;

public interface CustomerService {

	Customer registerUser(CustomerDto customerDto);

	Customer updateCustomer(Long customerId, CustomerDto customerDto) throws CustomerNotFoundException;

	void deleteCustomer(Long customerId) throws CustomerNotFoundException;


	List<Customer> getAllCustomers();

}
