package com.ordermanagement.customerservice.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ordermanagement.customerservice.dto.CustomerDto;
import com.ordermanagement.customerservice.exception.CustomerNotFoundException;
import com.ordermanagement.customerservice.model.Customer;
import com.ordermanagement.customerservice.service.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @PostMapping("/register")
    public ResponseEntity<String> registerCustomer(@RequestHeader String authorization, @RequestBody CustomerDto customerDto, final HttpServletRequest request) {
        Customer customer = customerService.registerUser(customerDto);
        return ResponseEntity.status(HttpStatus.CREATED).body("Customer is registered successfully");
    }

    @PutMapping("/{customerId}")
    public ResponseEntity<Customer> updateCustomer(@RequestHeader String authorization, @PathVariable("customerId") Long customerId, @RequestBody CustomerDto customerDto) throws CustomerNotFoundException{
        Customer updatedCustomer = customerService.updateCustomer(customerId,customerDto);
        return ResponseEntity.status(HttpStatus.OK).body(updatedCustomer);
    }

    @DeleteMapping("/{customerId}")
    public ResponseEntity<String> deleteCustomer(@RequestHeader String authorization, @PathVariable("customerId") Long customerId) throws CustomerNotFoundException {
        customerService.deleteCustomer(customerId);
        return ResponseEntity.status(HttpStatus.OK).body("Customer is deleted successfully with id : "+customerId);
    }

    @GetMapping
    public ResponseEntity<List<Customer>> getAllCustomers(@RequestHeader String authorization){
        return ResponseEntity.status(HttpStatus.OK).body(customerService.getAllCustomers());
    }
}
