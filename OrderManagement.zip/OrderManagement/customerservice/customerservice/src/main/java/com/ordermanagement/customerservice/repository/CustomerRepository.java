package com.ordermanagement.customerservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ordermanagement.customerservice.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

	
}
