package com.ordermanagement.customerservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ordermanagement.customerservice.dto.CustomerDto;
import com.ordermanagement.customerservice.exception.CustomerNotFoundException;
import com.ordermanagement.customerservice.model.Customer;
import com.ordermanagement.customerservice.repository.CustomerRepository;

@Service
public class Customerserviceimpl implements CustomerService {

	@Autowired
    private CustomerRepository customerRepository;

    @Override
    public Customer registerUser(CustomerDto customerDto) {
        Customer customer = Customer.builder()
                .customerName(customerDto.getCustomerName())
                .email(customerDto.getEmail())
                .mobileNumber(customerDto.getMobileNumber())
                .build();
        return customerRepository.save(customer);
    }

    @Override
    public Customer updateCustomer(Long customerId, CustomerDto customerDto) throws CustomerNotFoundException{
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() ->  new CustomerNotFoundException("Customer not found with Id : "+customerId));
        customer.setCustomerName(customerDto.getCustomerName());
        customer.setEmail(customerDto.getEmail());
        customer.setMobileNumber(customerDto.getMobileNumber());

        return customerRepository.saveAndFlush(customer);
    }

    @Override
    public void deleteCustomer(Long customerId) throws CustomerNotFoundException{
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() ->  new CustomerNotFoundException("Customer not found with Id : "+customerId));
        customerRepository.deleteById(customer.getCustomerId());
    }

    @Override
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

}
