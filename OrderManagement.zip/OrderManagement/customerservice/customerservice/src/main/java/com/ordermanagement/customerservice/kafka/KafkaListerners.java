package com.ordermanagement.customerservice.kafka;



import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;



@Component
@EnableKafka
public class KafkaListerners {


@KafkaListener(
topics ="ordermanage",
groupId = "groupId"
)
void listener(String data){
System.out.println("Listener received:" +data);
}
}