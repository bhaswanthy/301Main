package com.reviewmanagementservice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.reviewmanagementservice.dto.Restaurant;
import com.reviewmanagementservice.dto.RestaurantReview;
import com.reviewmanagementservice.dto.ReviewDto;
import com.reviewmanagementservice.exception.ReviewNotFoundException;
import com.reviewmanagementservice.model.Review;
import com.reviewmanagementservice.repository.ReviewRepository;

@Service
public class ReviewServiceImpl implements ReviewService {
@Autowired
private ReviewRepository reviewrepository;

@Autowired
private RestTemplate restTemplate;
@Override
	public Review insert(ReviewDto reviewdto) {
	Review review=Review.builder().
			description(reviewdto.getDescription()).
			comments(reviewdto.getComments()).
			restaurantId(reviewdto.getRestaurantId()).
			score(reviewdto.getScore()).
			build();
			
	return reviewrepository.save(review);
		
	}
@Override
public Review update(ReviewDto reviewdto, Long reviewid) {
 Review review=reviewrepository.findById(reviewid).orElseThrow(()->new ReviewNotFoundException("Review Not Found with id"+reviewid));
 review.setComments(reviewdto.getComments());
 review.setDescription(reviewdto.getDescription());
 review.setRestaurantId(reviewdto.getRestaurantId());
 review.setScore(reviewdto.getScore());
 return reviewrepository.saveAndFlush(review);
	
}
@Override
public void delete(Long reviewid) {
	Review review=reviewrepository.findById(reviewid).orElseThrow(()->new ReviewNotFoundException("Review Not Found with id"+reviewid));
	 reviewrepository.deleteById(reviewid);
}
@Override
public RestaurantReview get(Long restId) {
	
	List<Review> reviewList= reviewrepository.findAllByRestaurantId(restId);
	String url="http://localhost:8080/restaurantdetails/"+restId;
	Restaurant restaurant=restTemplate.getForObject(url, Restaurant.class);
	List<ReviewDto> reviewDtoList= new ArrayList<>();
	for(Review review:reviewList) {
		ReviewDto reviewDto=ReviewDto.builder().comments(review.getComments())
				.score(review.getScore())
				.description(review.getDescription())
				.restaurantId(review.getRestaurantId())
				.build();
		reviewDtoList.add(reviewDto);
	}
	RestaurantReview restaurantReview=RestaurantReview.builder().reviewDtoList(reviewDtoList)
			.restaurant(restaurant).build();
	return restaurantReview;
	
}




}
