package com.reviewmanagementservice.service;

import com.reviewmanagementservice.dto.RestaurantReview;
import com.reviewmanagementservice.dto.ReviewDto;
import com.reviewmanagementservice.model.Review;

public interface ReviewService {
	public Review insert(ReviewDto reviewdto);

	public Review update(ReviewDto reviewdto, Long reviewid);

	public void delete(Long reviewid);

	RestaurantReview get(Long restId);
}
