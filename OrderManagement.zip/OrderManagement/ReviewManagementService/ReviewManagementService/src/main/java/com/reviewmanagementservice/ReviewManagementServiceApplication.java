package com.reviewmanagementservice;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableEurekaClient
//@ConfigurationProperties("reviewmanagement")
public class ReviewManagementServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReviewManagementServiceApplication.class, args);
	}
	
	@Bean
	public RestTemplate getRestTemplate() {
	RestTemplate restTemplate = new RestTemplate();
//	restTemplate.getInterceptors().add((request, body, clientHttpRequestExecution) -> {
//	HttpHeaders headers = request.getHeaders();
//	if (!headers.containsKey("Authorization")) {
//	String token = bearerToken.toLowerCase().startsWith("bearer") ? bearerToken : "Bearer " + bearerToken;
//	request.getHeaders().add("Authorization", token);
//	}
//	return clientHttpRequestExecution.execute(request, body);
//	});@Value("${did-service.bearer-token}") String bearerToken
	return restTemplate;
	}
	
}
