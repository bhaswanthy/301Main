package com.reviewmanagementservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.reviewmanagementservice.dto.RestaurantReview;
import com.reviewmanagementservice.dto.ReviewDto;
import com.reviewmanagementservice.model.Review;
import com.reviewmanagementservice.service.ReviewService;
import com.reviewmanagementservice.service.ReviewServiceImpl;

@RestController
@RequestMapping("/review")
public class ReviewController {

	@Autowired
	private ReviewServiceImpl reviewservice;
	@PostMapping
	public ResponseEntity<Review> insertReview(@RequestBody ReviewDto reviewdto) {
		Review reviewInserted = reviewservice.insert(reviewdto);
		return ResponseEntity.status(HttpStatus.CREATED).body(reviewInserted);
	}
	@PutMapping("/{reviewid}")
	public ResponseEntity<Review> updateReview(@RequestBody ReviewDto reviewdto,@PathVariable Long reviewid){
		Review reviewUpdated=reviewservice.update(reviewdto,reviewid);
		return ResponseEntity.status(HttpStatus.OK).body(reviewUpdated);
	}
	
	@DeleteMapping("/{reviewid}")
	public ResponseEntity<String> deleteReview(@PathVariable Long reviewid){
		reviewservice.delete(reviewid);
		return ResponseEntity.status(HttpStatus.OK).body("Review is deleted with id:"+ reviewid);
	}
	@GetMapping("/{restId}")
	public ResponseEntity<RestaurantReview> getReviews(@PathVariable Long restId){
		RestaurantReview review=reviewservice.get(restId);
		return ResponseEntity.status(HttpStatus.OK).body(review);
	}
	
	
 	

}
