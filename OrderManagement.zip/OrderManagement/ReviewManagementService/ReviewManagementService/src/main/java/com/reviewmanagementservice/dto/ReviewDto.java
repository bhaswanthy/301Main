package com.reviewmanagementservice.dto;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.reviewmanagementservice.model.Review;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;



@AllArgsConstructor
@Getter
@Setter
@Builder
public class ReviewDto {

	private String comments;
	private String description;
	private Integer score;
	private Long restaurantId;
}

